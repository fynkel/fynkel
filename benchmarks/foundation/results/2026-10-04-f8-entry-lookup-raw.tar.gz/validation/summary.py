import json, math, statistics
from pathlib import Path

def distribution(values):
 values=sorted(values)
 return {'medianUs':statistics.median(values),'p95Us':values[math.ceil(.95*len(values))-1]}
result={'sustainedQualification':False,'diagnosticOverhead':True,'change':'Reuse the existing mutable entry lookup for in-place physics updates; preserve rebuild and validation behavior.', 'runs':[]}
for label,path in [('control','f8-entry-control-phone'),('candidate','f8-entry-candidate-phone'),('control2','f8-entry-control2-phone'),('candidate2','f8-entry-candidate2-phone')]:
 p=json.loads(Path('target',path,'capture.json').read_text())
 assert p['status']=='diagnostic-complete'
 rows=p['physicsSamples']
 ticks=[s for r in p['records'] if r['event']=='cpuTicks' for s in r['samples']]
 assert len(rows)==len(ticks)
 assert {r['world'] for r in rows}=={1}
 assert all(a['tick']==b['tick']+1 for a,b in zip(rows,ticks))
 assert all(r['ran']==1 for r in rows)
 systems=[{s['system']:s['micros'] for s in r['systems']} for r in ticks]
 result['runs'].append({'label':label,'captureId':p['captureId'],'source':path,'samples':len(rows),
  'phases':{k:distribution([r[k]/1000 for r in rows]) for k in rows[0] if k.endswith('_ns')},
  'systems':{k:distribution([r[k] for r in systems]) for k in ['physics','step']},
  'thermal':sorted({r['thermal'] for r in p['records'] if r['event']=='stats'}),
  'stop':[r['reason'] for r in p['records'] if r['event']=='stop'],
  'terminatedExactPid':p['terminatedExactPid']})
Path('benchmarks/foundation/results/2026-10-04-f8-entry-lookup.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result['runs']:
 print(r['label'],r['samples'],{k:round(v['medianUs'],2) for k,v in r['phases'].items()},r['systems'],r['thermal'])
