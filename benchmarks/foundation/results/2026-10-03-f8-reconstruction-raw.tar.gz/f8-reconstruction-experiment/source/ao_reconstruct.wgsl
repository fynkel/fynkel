// Full-resolution reconstruction of half-resolution AO/contact estimates.
// Surface normals and point-to-plane distance reject cross-surface samples.
// Missing support evaluates the original estimator at the actual output pixel.
@group(1) @binding(1) var ao_source: texture_2d<f32>;
@group(1) @binding(2) var ao_output: texture_storage_2d<rgba8unorm, write>;
var<workgroup> positions: array<vec4<f32>, 144>;
var<workgroup> estimates: array<vec4<f32>, 36>;
var<workgroup> representatives: array<vec2<i32>, 36>;
var<workgroup> refinement_mask: array<atomic<u32>, 144>;
var<workgroup> refined: array<vec2<f32>, 144>;

struct Reconstruction {
    value: vec2<f32>,
    refine: bool,
};

fn oct_decode(v: vec2<f32>) -> vec3<f32> {
    var n = vec3<f32>(v, 1.0 - abs(v.x) - abs(v.y));
    let t = max(-n.z, 0.0);
    n.x += select(t, -t, n.x >= 0.0);
    n.y += select(t, -t, n.y >= 0.0);
    return normalize(n);
}

fn reconstruct(c: vec2<i32>, local: vec2<u32>, size: vec2<i32>,
               origin: vec2<i32>, low_origin: vec2<i32>, low_size: vec2<i32>) -> Reconstruction {
    let center_index = (local.y + 2u) * 12u + local.x + 2u;
    let center = positions[center_index];
    if center.w >= 1.0 {
        return Reconstruction(vec2<f32>(1.0), false);
    }
    let left = positions[center_index - 1u];
    let right = positions[center_index + 1u];
    let up = positions[center_index - 12u];
    let down = positions[center_index + 12u];
    var hx = right.xyz - center.xyz;
    if c.x == size.x - 1 || (c.x > 0 && abs(left.w - center.w) < abs(right.w - center.w)) {
        hx = center.xyz - left.xyz;
    }
    var hy = down.xyz - center.xyz;
    if c.y == size.y - 1 || (c.y > 0 && abs(up.w - center.w) < abs(down.w - center.w)) {
        hy = center.xyz - up.xyz;
    }
    var normal = cross(hx, hy);
    if dot(normal, normal) < 1e-16 {
        return Reconstruction(vec2<f32>(1.0), true);
    }
    normal = normalize(normal);
    if dot(normal, frame.camera_pos.xyz - center.xyz) < 0.0 { normal = -normal; }
    let tolerance = 0.25 * max(length(hx), length(hy)) + 0.0001;
    let base = local / 2u;
    var sum = vec2<f32>(0.0);
    var weights = 0.0;
    var discontinuity = false;
    for (var y = 0u; y < 3u; y++) {
        for (var x = 0u; x < 3u; x++) {
            let lc = low_origin + vec2<i32>(base + vec2<u32>(x, y));
            if any(lc < vec2<i32>(0)) || any(lc >= low_size) { continue; }
            let i = (base.y + y) * 6u + base.x + x;
            let rc = representatives[i];
            let pc = clamp(rc - origin, vec2<i32>(0), vec2<i32>(11));
            let p = positions[u32(pc.y) * 12u + u32(pc.x)];
            let value = estimates[i];
            if p.w >= 1.0 { continue; }
            if dot(normal, oct_decode(value.ba)) < 0.85 || abs(dot(normal, p.xyz - center.xyz)) > tolerance {
                discontinuity = true;
                continue;
            }
            let delta = abs(vec2<f32>(rc - c));
            let weight = max(0.0, 3.0 - delta.x) * max(0.0, 3.0 - delta.y);
            sum += value.rg * weight;
            weights += weight;
        }
    }
    if weights > 0.0 && !discontinuity { return Reconstruction(sum / weights, false); }
    return Reconstruction(vec2<f32>(1.0), true);
}

@compute @workgroup_size(8, 8)
fn cs_main(@builtin(workgroup_id) group: vec3<u32>,
           @builtin(local_invocation_id) local: vec3<u32>,
           @builtin(local_invocation_index) index: u32) {
    let size = vec2<i32>(textureDimensions(depth_tex));
    let low_size = vec2<i32>(textureDimensions(ao_source));
    let origin = vec2<i32>(group.xy * 8u) - vec2<i32>(2);
    let low_origin = vec2<i32>(group.xy * 4u) - vec2<i32>(1);
    for (var i = index; i < 144u; i += 64u) {
        let c = clamp(origin + vec2<i32>(i32(i % 12u), i32(i / 12u)), vec2<i32>(0), size - 1);
        let depth = depth_at(c);
        positions[i] = vec4<f32>(world_at((vec2<f32>(c) + 0.5) / vec2<f32>(size), depth), depth);
    }
    if index < 36u {
        let c = clamp(low_origin + vec2<i32>(i32(index % 6u), i32(index / 6u)), vec2<i32>(0), low_size - 1);
        estimates[index] = textureLoad(ao_source, c, 0);
        representatives[index] = representative(c, size);
    }
    workgroupBarrier();
    let c = vec2<i32>(group.xy * 8u + local.xy);
    let valid = all(c < size);
    var result = Reconstruction(vec2<f32>(1.0), false);
    if valid { result = reconstruct(c, local.xy, size, origin, low_origin, low_size); }
    if result.refine {
        for (var y = -2; y < 2; y++) {
            for (var x = -2; x < 2; x++) {
                let q = c + vec2<i32>(x, y);
                if any(q < vec2<i32>(0)) || any(q >= size) { continue; }
                let k = vec2<i32>(local.xy) + vec2<i32>(2 + x, 2 + y);
                atomicStore(&refinement_mask[u32(k.y) * 12u + u32(k.x)], 1u);
            }
        }
    }
    workgroupBarrier();
    // Evaluate each requested full-resolution tap once per workgroup, rather
    // than repeating its ray marches for every neighbouring output pixel.
    for (var i = index; i < 144u; i += 64u) {
        if atomicLoad(&refinement_mask[i]) != 0u {
            let q = origin + vec2<i32>(i32(i % 12u), i32(i / 12u));
            refined[i] = round(clamp(estimate_at(q, size).rg, vec2<f32>(0.0), vec2<f32>(1.0)) * 255.0) / 255.0;
        }
    }
    workgroupBarrier();
    if !valid { return; }
    if result.refine {
        let center_index = (local.y + 2u) * 12u + local.x + 2u;
        let center = distance(positions[center_index].xyz, frame.camera_pos.xyz);
        var sum = vec2<f32>(0.0);
        var weights = 0.0;
        for (var y = -2; y < 2; y++) {
            for (var x = -2; x < 2; x++) {
                let q = c + vec2<i32>(x, y);
                if any(q < vec2<i32>(0)) || any(q >= size) { continue; }
                let k = vec2<i32>(local.xy) + vec2<i32>(2 + x, 2 + y);
                let i = u32(k.y) * 12u + u32(k.x);
                if abs(distance(positions[i].xyz, frame.camera_pos.xyz) - center) > 0.02 * max(center, 1.0) { continue; }
                sum += refined[i];
                weights += 1.0;
            }
        }
        result.value = sum / weights; // the center tap is always included
    }
    textureStore(ao_output, c, vec4<f32>(result.value, 0.0, 1.0));
}
