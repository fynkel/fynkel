import json, tarfile
from pathlib import Path
out={'scope':'Frozen dense-5000 effect isolation with Metal profiling; no runtime optimization or FPS gain claimed.','sustainedQualification':False,'executionWindowMs':[3500,7000],'runs':[]}
for mode in ['ao','contact','both']:
 folder=Path('target/f8-metal-usb-'+mode)
 c=json.loads((folder/'capture.json').read_text())
 assert c['status']=='diagnostic-complete' and c['metalTraceExitCode']==0 and c['pid']==c['terminatedExactPid']
 assert c['records'][0]['awaitProfiler'] and c['records'][0]['frozenScene']
 assert any(r['event']=='profiler-ready' and r['captureId']==c['captureId'] for r in c['records'])
 rows=[r for r in c['records'] if r['event']=='stats'];assert all(r['qualityVerified'] for r in rows)
 out['runs'].append({'mode':mode,'captureId':c['captureId'],'pid':c['pid'],'quality':c['records'][0]['quality'],'frameworkSha256':c['frameworkSha256'],'dimensions':sorted({(r['width'],r['height']) for r in rows}),'thermal':sorted({r['thermal'] for r in rows}),'stop':c['records'][-1]['reason'],'fullTrace':json.loads((folder/'metal-summary.json').read_text()),'middleWindow':json.loads((folder/'metal-window.json').read_text())})
assert out['runs'][0]['frameworkSha256']==out['runs'][1]['frameworkSha256']==out['runs'][2]['frameworkSha256']
Path('benchmarks/foundation/results/2026-10-04-f8-metal-effects.json').write_text(json.dumps(out,indent=2)+'\n')
with tarfile.open('benchmarks/foundation/results/2026-10-04-f8-metal-effects-raw.tar.gz','w:gz') as t:
 for n in ['f8-metal-usb-ao','f8-metal-usb-contact','f8-metal-usb-both','f8-profiler-process-discovery','f8-profiler-name-discovery']:
  for p in Path('target',n).iterdir():
   if p.is_file() and p.name!='processes.json':t.add(p,arcname=n+'/'+p.name)
 for n in ['f8-gate-hardening-python.log','f8-gate-hardening-dart.log','f8-gate-hardening-analysis.log','f8-gate-hardening-ios.log','f8-profiler-launch-probe.log','f8-process-discovery.log','f8-name-discovery.log','f8-metal-usb-summary.py']:
  t.add(Path('/tmp',n),arcname='checks/'+n)
for r in out['runs']:print(r['mode'],r['thermal'],r['dimensions'])
