import json,re,statistics,hashlib
from pathlib import Path
out={'sustainedQualification':False,'scope':'Dense-5000 medium. Frozen captures include GPU tracing; live captures omit extra trace readbacks. GPU spans overlap; acquisitions are not display scanout.','runs':[]}
for mode in ['frozen','live']:
 for name in ['control','candidate','candidate2','control2']:
  folder=Path('target/f8-fixed-blur-'+name+'-'+mode)
  if not (folder/'capture.json').exists():continue
  p=json.loads((folder/'capture.json').read_text());assert p['status']=='diagnostic-complete',p['status']
  w=[r for r in p['records'] if r['event']=='stats'];assert all(r['qualityVerified'] for r in w)
  g=[float(m.group(1)) for r in w if (m:=re.search(r'(?:^| )gpu_frame=([0-9.]+)',r['summary']))]
  r={'name':name,'mode':mode,'captureId':p['captureId'],'gpuWindowP50Ms':g,'gpuMedianWindowP50AfterFirstMs':statistics.median(g[1:]),'acquiredFramesPerSecond':None if any(r['acquiredFps'] is None for r in w) else sum(r['acquiredFps']*r['windowSeconds'] for r in w)/sum(r['windowSeconds'] for r in w),'dimensions':sorted({(r['width'],r['height']) for r in w}),'thermal':sorted({r['thermal'] for r in w}),'terminatedExactPid':p['terminatedExactPid'],'stop':p['records'][-1]['reason'],'frameworkSha256':p['frameworkSha256']}
  if p.get('screenSpaceSamples'):r.update(blurMedianUs=statistics.median(x['blurUs'] for x in p['screenSpaceSamples']),gpuSamples=len(p['screenSpaceSamples']))
  for field in ['gpu_frame','present_lag','interval','native','work','extract','prepare']:
   values=[tuple(float(v) for v in m.groups()) for x in w if (m:=re.search(r'(?:^| )'+field+r'=([0-9.]+)/([0-9.]+)/([0-9.]+)',x['summary']))]
   r[field+'WindowP50P95Max']=values
  r['simulationTicks']=[x.get('simulationTick') for x in w]
  out['runs'].append(r)
b=Path('/tmp/f8-fixed-blur-baseline-images');c=Path('/tmp/f8-fixed-blur-candidate-images');names=sorted(p.name for p in b.glob('*.ppm'));assert len(names)==68 and sorted(p.name for p in c.glob('*.ppm'))==names
out['imageDifferences']={}
for n in names:
 a=(b/n).read_bytes();v=(c/n).read_bytes();assert len(a)==len(v)
 ds=[abs(x-y) for x,y in zip(a,v) if x!=y]
 if ds:out['imageDifferences'][n]={'changedBytes':len(ds),'maxByteDifference':max(ds),'sumByteDifference':sum(ds)}
out['baselineImageSha256']={n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in names}
Path('/tmp/f8-fixed-blur-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out['runs']:print(r['name'],r['mode'],'GPU',r['gpuMedianWindowP50AfterFirstMs'],'acq',r['acquiredFramesPerSecond'],'blur',r.get('blurMedianUs'),r['thermal'])
