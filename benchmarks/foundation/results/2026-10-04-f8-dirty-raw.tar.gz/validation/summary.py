import json,statistics,math,re
from pathlib import Path

def stats(values):
 values=sorted(values);return {'medianUs':statistics.median(values),'p95Us':values[math.ceil(.95*len(values))-1]}
out={'retained':False,'decision':'Removed: propagation is cheaper but phone whole-step timings are mixed and untraced acquisition shows no repeatable benefit. First untraced pair regressed; reverse-order pair tied. Cause of run-to-run variation not isolated.','sustainedQualification':False,'runs':[]}
for label in ['control-phone','candidate-phone','control-ordinary','candidate-ordinary','control2-phone','candidate2-phone','candidate2-ordinary','control2-ordinary']:
 p=json.loads(Path('target/f8-dirty-'+label+'/capture.json').read_text());assert p['status']=='diagnostic-complete'
 r={'label':label,'captureId':p['captureId'],'tracePhysics':p['tracePhysics'],'terminatedExactPid':p['terminatedExactPid']}
 windows=[a for a in p['records'] if a['event']=='stats'];r['thermal']=sorted({x['thermal'] for x in windows})
 r['missingAcquisitionWindows']=sum(x['acquiredFps'] is None for x in windows)
 r['acquiredFramesPerSecond']=None if r['missingAcquisitionWindows'] else sum(x['acquiredFps']*x['windowSeconds'] for x in windows)/sum(x['windowSeconds'] for x in windows)
 r['stop']=[a['reason'] for a in p['records'] if a['event']=='stop']
 if p['tracePhysics']:
  rows=p['physicsSamples'];ticks=[s for a in p['records'] if a['event']=='cpuTicks' for s in a['samples']]
  assert len(rows)==len(ticks) and {x['world'] for x in rows}=={1}
  assert all(a['tick']==b['tick']+1 for a,b in zip(rows,ticks))
  r['ticks']=len(rows)
  r['phases']={k:stats([x[k]/1000 for x in rows]) for k in ['propagation_ns','core_total_ns','total_ns']}
  r['allTickSystems']={k:stats([next(s['micros'] for s in x['systems'] if s['system']==k) for x in ticks]) for k in ['step','physics','transforms']}
 else:
  r['hostNativeWindowMedianMs']=[float(re.search(r'(?:^| )native=([0-9.]+)', x['summary']).group(1)) for x in windows]
  r['medianOfHostNativeWindowMediansMs']=statistics.median(r['hostNativeWindowMedianMs'])
 out['runs'].append(r)
Path('benchmarks/foundation/results/2026-10-04-f8-dirty.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
