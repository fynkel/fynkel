import importlib.util,subprocess,time,json
from pathlib import Path
s=importlib.util.spec_from_file_location('capture','benchmarks/mobile/capture.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
original=m.subprocess.Popen
out=Path('target/f8-metal-gated-discovery')
def spawn(command,**kwargs):
 if command[:3]==['xcrun','xctrace','record']:
  # Diagnostic only: separate devicectl launch completion from Instruments discovery.
  time.sleep(2)
 return original(command,**kwargs)
m.subprocess.Popen=spawn
m.capture('0B7504CE-4917-5F8B-9F4C-B05BC9FF8D2D','com.fynkel.qualification.mobileDense5000',Path('target/f8-mobile-app-500/build/ios/iphoneos/Runner.app'),out,freeze_scene=True,quality='medium-no-contact',metal_trace_device='00008140-0014710C3EFB001C')
