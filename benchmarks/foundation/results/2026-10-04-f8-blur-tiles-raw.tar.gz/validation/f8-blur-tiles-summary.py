import json,re,statistics,hashlib
from pathlib import Path
out={'retained':False,'sustainedQualification':False,'scope':'Frozen dense-5000, medium, GPU tracing; spans may overlap and are not additive. No live-game performance claim.','runs':[]}
for label,path in [('8x8 control','f8-blur16-control-frozen'),('16x16','f8-blur16-candidate-frozen'),('16x8','f8-blur16x8-candidate-frozen'),('8x8 repeat','f8-blur16-control2-frozen')]:
 p=json.loads(Path('target',path,'capture.json').read_text());assert p['status']=='diagnostic-complete'
 assert p['records'][0]['frozenScene']
 w=[x for x in p['records'] if x['event']=='stats'];assert all(x['qualityVerified'] for x in w)
 gpu=[float(m.group(1)) for x in w if (m:=re.search(r'(?:^| )gpu_frame=([0-9.]+)',x['summary']))]
 r={'label':label,'captureId':p['captureId'],'gpuFrameMedianOfWindowP50Ms':statistics.median(gpu),'gpuFrameMedianOfWindowP50AfterFirstMs':statistics.median(gpu[1:]),'gpuWindowP50Ms':gpu,'blurMedianUs':statistics.median(x['blurUs'] for x in p['screenSpaceSamples']),'screenSpaceSamples':len(p['screenSpaceSamples']),'acquiredFramesPerSecond':None if any(x['acquiredFps'] is None for x in w) else sum(x['acquiredFps']*x['windowSeconds'] for x in w)/sum(x['windowSeconds'] for x in w),'dimensions':sorted({(x['width'],x['height']) for x in w}),'thermal':sorted({x['thermal'] for x in w}),'terminatedExactPid':p['terminatedExactPid'],'stop':[x['reason'] for x in p['records'] if x['event']=='stop']}
 out['runs'].append(r)
b=Path('/tmp/f8-blur16-baseline-images');names=sorted(p.name for p in b.glob('*.ppm'));assert len(names)==68
for c in ['/tmp/f8-blur16-candidate-images','/tmp/f8-blur16x8-images']:
 assert sorted(p.name for p in Path(c).glob('*.ppm'))==names
 assert all((b/n).read_bytes()==(Path(c)/n).read_bytes() for n in names)
out['identicalImagesPerCandidate']=68
out['baselineImageSha256']={n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in names}
Path('benchmarks/foundation/results/2026-10-04-f8-blur-tiles.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out['runs']:print(r)
