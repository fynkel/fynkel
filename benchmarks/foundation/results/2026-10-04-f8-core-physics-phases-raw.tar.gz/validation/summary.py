import json,statistics,math
from pathlib import Path
p=json.loads(Path('target/f8-core-phases-phone/capture.json').read_text())
assert p['status']=='diagnostic-complete'
r=p['physicsSamples']; t=[s for a in p['records'] if a['event']=='cpuTicks' for s in a['samples']]
assert len(r)==len(t) and {x['world'] for x in r}=={1}
assert all(a['tick']==b['tick']+1 and a['ran']==1 for a,b in zip(r,t))
systems=[{x['system']:x['micros'] for x in a['systems']} for a in t]
assert all(s['physics']+1 >= a['core_total_ns']/1000 for s,a in zip(systems,r))
def stats(v):
 v=sorted(v);return {'medianUs':statistics.median(v),'p95Us':v[math.ceil(.95*len(v))-1]}
out={'captureId':p['captureId'],'samples':len(r),'diagnosticOverhead':True,'sustainedQualification':False,'phases':{k:stats([x[k]/1000 for x in r]) for k in r[0] if k.endswith('_ns')},'systems':{k:stats([x[k] for x in systems]) for k in ['physics','step']},'schedulerOutsideCore':stats([s['physics']-a['core_total_ns']/1000 for s,a in zip(systems,r)]),'thermal':sorted({a['thermal'] for a in p['records'] if a['event']=='stats'}),'stop':[a for a in p['records'] if a['event']=='stop'],'terminatedExactPid':p['terminatedExactPid'],'interpretation':'Propagation dominates the core physics residual. Core adapter includes the nested physics adapter phases; do not add nested totals. Scheduler residual is subject to whole-microsecond truncation.'}
Path('benchmarks/foundation/results/2026-10-04-f8-core-physics-phases.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
