import json,subprocess,time,uuid
from pathlib import Path
out=Path('target/f8-gate-handshake-check');out.mkdir()
d='0B7504CE-4917-5F8B-9F4C-B05BC9FF8D2D';b='com.fynkel.qualification.mobileDense5000';cid=uuid.uuid4().hex
r={'captureId':cid,'awaitProfiler':True,'freezeScene':True,'quality':'medium'}
(out/'request.json').write_text(json.dumps(r))
def run(a):
 return subprocess.run(['xcrun','devicectl',*map(str,a)],capture_output=True,text=True,check=True,timeout=30)
def copy_to(src,dest):
 run(['device','copy','to','--device',d,'--domain-type','appDataContainer','--domain-identifier',b,'--source',src,'--destination',dest])
copy_to(out/'request.json','Documents/capture-request.json');pid=None
try:
 run(['device','process','launch','--device',d,'--terminate-existing','--json-output',out/'launch.json',b])
 pid=json.loads((out/'launch.json').read_text())['result']['process']['processIdentifier']
 time.sleep(2)
 (out/'go.json').write_text(json.dumps({'captureId':cid}))
 copy_to(out/'go.json',f'Documents/capture-go-{cid}.json')
 time.sleep(12)
finally:
 if pid:run(['device','process','terminate','--device',d,'--pid',pid])
run(['device','copy','from','--device',d,'--domain-type','appDataContainer','--domain-identifier',b,'--source','Documents/mobile-capture.jsonl','--destination',out/'mobile-capture.jsonl'])
rows=[json.loads(l) for l in (out/'mobile-capture.jsonl').read_text().splitlines()]
assert rows[0]['captureId']==cid and rows[0]['awaitProfiler']
assert any(x['event']=='profiler-ready' and x['captureId']==cid for x in rows)
assert any(x['event']=='stats' for x in rows)
assert rows[-1]['reason']=='deadline'
(out/'verification.json').write_text(json.dumps({'scope':'Manual start-signal validation only. No Metal profiler or performance claim.','captureId':cid,'pid':pid,'terminatedExactPid':pid,'passed':True},indent=2)+'\n')
print('PASS: matching signal releases scene; bounded deadline and exact PID stop')
