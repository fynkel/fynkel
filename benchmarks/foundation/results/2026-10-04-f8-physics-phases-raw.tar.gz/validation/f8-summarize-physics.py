import json, statistics, math
from pathlib import Path
root=Path.cwd()
p=json.loads((root/'target/f8-physics-phases-phone/capture.json').read_text())
assert p['status']=='diagnostic-complete'
phases=p['physicsSamples']
ticks=[s for r in p['records'] if r['event']=='cpuTicks' for s in r['samples']]
assert len(phases)==len(ticks)==479
assert {r['world'] for r in phases}=={1}
assert all(a['tick']==b['tick']+1 for a,b in zip(phases,ticks))
def summary(a):
 a=sorted(a)
 return dict(medianUs=statistics.median(a),p95Us=a[math.ceil(.95*len(a))-1],meanUs=statistics.mean(a))
fields=[k for k in phases[0] if k.endswith('_ns')]
systems=[{s['system']:s['micros'] for s in r['systems']} for r in ticks]
residual=[s['physics']-p['total_ns']/1000 for p,s in zip(phases,systems)]
assert min(residual)>=0
out=dict(captureId=p['captureId'],status=p['status'],sustainedQualification=False,diagnosticOverhead=True,world=1,samples=len(phases),
 tickMapping='Native completed tick = SDK pre-step tick + 1; all 479 rows matched.',
 phases={k.removesuffix('_ns'):summary([r[k]/1000 for r in phases]) for k in fields},
 systems={k:summary([s[k] for s in systems]) for k in ['physics','step']},
 physicsSystemOutsideAdapter=summary(residual),
 interpretation='Residual includes scene propagation and core event/rejection work, not exclusively propagation. Timers and file writes add overhead; this is phase attribution, not a throughput comparison.',
 thermalStates=sorted({r['thermal'] for r in p['records'] if r['event']=='stats'}),
 stop=[r for r in p['records'] if r['event']=='stop'],terminatedExactPid=p['terminatedExactPid'])
path=root/'benchmarks/foundation/results/2026-10-04-f8-physics-phases.json'
path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
