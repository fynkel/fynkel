import json, statistics, hashlib, tarfile
from pathlib import Path
root=Path.cwd()
p=root/'benchmarks/foundation/results/2026-10-05-f8-pose-views.json'
result=json.loads(p.read_text())
for label,app in [('candidate-cooled','target/f8-mobile-app-500/build/ios/iphoneos/Runner.app'),('control-cooled','target/f8-pose-views-control.app'),('candidate-cooled-repeat','target/f8-mobile-app-500/build/ios/iphoneos/Runner.app')]:
 d=root/f'target/f8-pose-views-{label}'; c=json.loads((d/'capture.json').read_text()); s=json.loads((d/'frame-summary.json').read_text()); records=c['records']; ticks=next(r['samples'] for r in records if r['event']=='cpuTicks')
 assert c['status']=='diagnostic-complete' and c.get('terminatedExactPid')
 assert all(r['thermal']=='nominal' for r in records if r['event']=='stats')
 medians={name:statistics.median(v['micros'] for t in ticks for v in t['systems'] if v['system']==name) for name in [v['system'] for v in ticks[0]['systems']]}
 hashes={str(f.relative_to(root/app)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/app/'Frameworks').glob('*.framework/*') if f.is_file() and f.name==f.parent.stem}
 result['runs'].append(dict(label=label,captureId=c['captureId'],frameworkSha256=hashes,thermal=['nominal'],terminatedExactPid=c['terminatedExactPid'],ticks=len(ticks),systemMedianUs=medians,freshAcquisitionsPerSecond=s['freshAcquisitionsPerSecond'],stagesUs=s['stagesUs']))
result['mobileQualification']='retained targeted CPU improvement: all-nominal candidate/control/candidate sequence; lookAtCamera median 674.5/736/628 us; no repeatable whole-frame improvement established'
result['decision']='Retain shared pose reads; preserve workload, quality and atomic publication. F8 sustained 60/120 FPS and thermal qualification remain open.'
p.write_text(json.dumps(result,indent=2)+'\n')
doc=root/'docs/foundation-f8-pose-views.md';text=doc.read_text();text=text.replace('Implementation and local correctness checks are complete. Mobile performance\nacceptance is pending a cooled comparison; the first candidate run reported fair\nthermal state and was stopped at the bounded deadline. F8 remains open.','Implementation and local correctness checks are complete. A subsequent all-nominal\ncandidate/control/candidate sequence supports retaining the targeted CPU saving,\nwithout establishing a repeatable full-frame gain. The earlier warmer candidate\nremains excluded from acceptance. F8 remains open.')
start=text.index('## Current decision')
text=text[:start]+'''## Normal-thermal repeat sequence

The connected phone completed three more eight-second captures, in reverse order
followed by one candidate repeat. All eight thermal samples in every run were
nominal; exact PIDs 10678, 10681 and 10682 were terminated before copying evidence.
"Cooled" directory names identify the requested repeat; normal thermal state was
verified by the app, not by an additional user report of physical temperature.
Medium quality, 1320×2868, workload and diagnostic options were unchanged.

| Build / order | Native tick median ms | LookAtCamera median ms | New acquisitions/s | Thermal |
| --- | ---: | ---: | ---: | --- |
| Candidate first | 7.385 | 0.6745 | 37.52 | nominal |
| Control second | 7.202 | 0.736 | 39.06 | nominal |
| Candidate repeat | 7.020 | 0.628 | 39.95 | nominal |

Camera-facing work is 8.4% and 14.7% lower than the intervening control. Other
stages vary between runs, and full-frame acquisition rates are lower in the first
candidate and higher in the repeat. These short diagnostics establish a targeted
saving, not a repeatable overall throughput improvement or sustained qualification.
No visual quality, simulation rate or transaction guarantees were reduced.

## Current decision

Retain the shared-read implementation on the strength of correctness coverage,
the local microbenchmark and lower camera-facing stage cost in both normal-thermal
candidate runs. Do not claim a full-game FPS gain. Current physics medians remain
4.177–4.374 ms per tick, and prior GPU traces remain well above the 8.33 ms budget
for 120 FPS. Next focus is the measured physics synchronization and GPU screen-space
costs; this conversion optimization does not resolve either bottleneck.

[Results](../benchmarks/foundation/results/2026-10-05-f8-pose-views.json),
[original raw evidence](../benchmarks/foundation/results/2026-10-05-f8-pose-views-raw.tar.gz)
and [normal-thermal repeat evidence](../benchmarks/foundation/results/2026-10-05-f8-pose-views-cooled-raw.tar.gz).
'''
doc.write_text(text)
entry='''
## 2026-10-05 — shared pose reads retained after normal-thermal repeats

All-nominal candidate/control/candidate eight-second sequence completed, with
exact PIDs stopped. LookAtCamera medians 0.6745 / 0.736 / 0.628 ms support an
8–15% targeted saving. Native ticks 7.385 / 7.202 / 7.020 ms and acquisitions
37.52 / 39.06 / 39.95 per second do not establish repeatable whole-frame gain.
Retained on local correctness and targeted CPU evidence; earlier fair candidate
remains excluded. No quality/workload/rate reductions. F8 and sustained thermal
60/120 FPS qualification remain open. Physics synchronization and GPU screen-space
costs remain the larger priorities. See [pose-read evidence](foundation-f8-pose-views.md).
'''
for name in ['foundation-f8-gate-report.md','foundation-f8-device-observations.md']:
 with (root/'docs'/name).open('a') as f:f.write(entry)
archive=root/'benchmarks/foundation/results/2026-10-05-f8-pose-views-cooled-raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for label in ['candidate-cooled','control-cooled','candidate-cooled-repeat']:
  path=root/f'target/f8-pose-views-{label}';tar.add(path,arcname=str(path.relative_to(root)))
 for name in ['crates/fynkel_scene/src/lib.rs','crates/fynkel_scene/tests/native_pose_batch.rs','benchmarks/mobile/capture.py','benchmarks/mobile/analyze_frames.py','docs/foundation-f8-pose-views.md','benchmarks/foundation/results/2026-10-05-f8-pose-views.json']:
  tar.add(root/name,arcname=name)
 tar.add('/tmp/f8-pose-cooled-evidence.py',arcname='summarize-cooled.py')
print('Updated qualification evidence; original archive preserved.')
