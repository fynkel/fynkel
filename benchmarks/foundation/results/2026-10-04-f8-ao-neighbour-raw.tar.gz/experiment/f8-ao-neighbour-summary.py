import json,re,statistics,hashlib
from pathlib import Path
out={'retained':False,'sustainedQualification':False,'scope':'Frozen dense-5000, medium, GPU tracing. GPU spans may overlap; acquisition is not display scanout.','runs':[]}
for name in ['control','candidate','candidate2','control2']:
 p=json.loads(Path('target/f8-ao-neighbour-'+name+'/capture.json').read_text());assert p['status']=='diagnostic-complete'
 assert p['records'][0]['frozenScene']
 w=[x for x in p['records'] if x['event']=='stats'];assert all(x['qualityVerified'] for x in w)
 g=[float(m.group(1)) for x in w if (m:=re.search(r'(?:^| )gpu_frame=([0-9.]+)',x['summary']))]
 r={'label':name,'captureId':p['captureId'],'gpuWindowP50Ms':g,'gpuFrameMedianOfWindowP50AfterFirstMs':statistics.median(g[1:]),'estimateMedianUs':statistics.median(x['estimateUs'] for x in p['screenSpaceSamples']),'sampleCount':len(p['screenSpaceSamples']),'acquiredFramesPerSecond':None if any(x['acquiredFps'] is None for x in w) else sum(x['acquiredFps']*x['windowSeconds'] for x in w)/sum(x['windowSeconds'] for x in w),'dimensions':sorted({(x['width'],x['height']) for x in w}),'thermal':sorted({x['thermal'] for x in w}),'terminatedExactPid':p['terminatedExactPid'],'stop':[x['reason'] for x in p['records'] if x['event']=='stop']}
 out['runs'].append(r)
b=Path('/tmp/f8-ao-neighbour-baseline-images');c=Path('/tmp/f8-ao-neighbour-candidate-images');z=Path('/tmp/f8-ao-neighbour-restored-images');names=sorted(p.name for p in b.glob('*.ppm'));assert len(names)==68
assert sorted(p.name for p in c.glob('*.ppm'))==names
assert sorted(p.name for p in z.glob('*.ppm'))==names
assert all((b/n).read_bytes()==(z/n).read_bytes() for n in names)
out['imageDifferences']={}
for n in names:
 a=(b/n).read_bytes();v=(c/n).read_bytes();assert len(a)==len(v)
 ds=[abs(x-y) for x,y in zip(a,v) if x!=y]
 if ds:out['imageDifferences'][n]={'changedBytes':len(ds),'maxByteDifference':max(ds),'sumByteDifference':sum(ds)}
out['restoredImagesIdentical']=68
out['baselineImageSha256']={n:hashlib.sha256((b/n).read_bytes()).hexdigest() for n in names}
Path('benchmarks/foundation/results/2026-10-04-f8-ao-neighbour.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out['runs']:print(r)
